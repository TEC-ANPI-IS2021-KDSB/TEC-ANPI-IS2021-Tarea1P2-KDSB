#include <iostream>
using namespace std;

const double tol = 1E-08;           //Tolerancia permitida en los calculos

double div_1t(double a);              //Done
double sin_t(double x);             //Done
double tan_t(double x);             //Done
double log_t(double x, double a);   //Done
double sinh_t(double x);            //Done
double tanh_t(double x);            //Done
double root_t(double x, double a);  //Done
double atan_t(double x);            //Done
double exp_t(double x);             //Done
double cos_t(double x);             //Done
double ln_t(double x);              //Done
double power_t(double x, double a); //Done
double cosh_t(double x);            //Done
double sqrt_t(double x);            //Done
double asin_t(double x);            //Done

double factorial (int n);           //Done

